# MERN Todo Project

This is a simple MERN stack Todo application example.

## Structure
- /backend - Express + MongoDB API
- /frontend - React app

## Quick start

1. Start MongoDB (local or Atlas). Set MONGO_URI in backend/.env
2. Backend:
   ```
   cd backend
   npm install
   npm start
   ```
3. Frontend:
   ```
   cd frontend
   npm install
   npm start
   ```
The frontend expects the backend API at http://localhost:5000/api by default.

