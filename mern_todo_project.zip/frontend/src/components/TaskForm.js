import React, { useState } from 'react';

export default function TaskForm({ onAdd }) {
  const [title, setTitle] = useState('');

  const submit = (e) => {
    e.preventDefault();
    if (!title.trim()) return;
    onAdd(title.trim());
    setTitle('');
  };

  return (
    <form onSubmit={submit} style={{ marginBottom: 20 }}>
      <input
        value={title}
        onChange={e => setTitle(e.target.value)}
        placeholder="New task"
        style={{ padding: 8, width: '70%', marginRight: 8 }}
      />
      <button type="submit" style={{ padding: '8px 12px' }}>Add</button>
    </form>
  );
}
