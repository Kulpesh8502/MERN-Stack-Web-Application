import React from 'react';

export default function TaskList({ tasks, onToggle, onDelete }) {
  if (!tasks.length) return <p>No tasks yet.</p>;

  return (
    <ul style={{ listStyle: 'none', padding: 0 }}>
      {tasks.map(task => (
        <li key={task._id} style={{ padding: 8, borderBottom: '1px solid #eee', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <input type="checkbox" checked={task.completed} onChange={() => onToggle(task._id)} />
            <span style={{ marginLeft: 8, textDecoration: task.completed ? 'line-through' : 'none' }}>{task.title}</span>
          </div>
          <button onClick={() => onDelete(task._id)} style={{ background: 'transparent', border: 'none', cursor: 'pointer' }}>Delete</button>
        </li>
      ))}
    </ul>
  );
}
